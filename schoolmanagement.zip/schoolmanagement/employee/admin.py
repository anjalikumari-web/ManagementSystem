from django.contrib import admin

from .models import *
# Register your models here.

admin.site.register(EmployeeAddressInfo)
admin.site.register(EducationInfo)
admin.site.register(TrainingInfo)
admin.site.register(EmployeeJobInfo)
admin.site.register(ExperienceInfo)
admin.site.register(PersonalInfo)
